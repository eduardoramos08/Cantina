To learn more about the font family and its license, visit https://www.fontmirror.com/agrandir

License: Free for personal use.
This is a preview font for testing, you can purchase its full version at https://pangrampangram.com/products/agrandir.
To learn more about the font, visit https://www.behance.net/gallery/74042877/Agrandir-Typeface-Free-Fonts-Variable-Font.